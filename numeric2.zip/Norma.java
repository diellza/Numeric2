import javax.swing.*;


public class Norma {
	private static double[] vektori;
	private static double[][] matrica;

	

	public static double[] definoVektorin() {
int length = new Integer(JOptionPane.showInputDialog(" Shkruaj gjatesine e vargut  ")).intValue();
		if (length > 0) {
			vektori = new double[length];
		}
		return vektori;
	}

	public static double[][] definoMatricen() {
int num_rreshtave = new Integer(JOptionPane.showInputDialog(" Shkruaj numrin e reshtave te  matrices ")).intValue();
int num_shtyllave = new Integer(JOptionPane.showInputDialog(" Shkruaj numrin e shtyllave te  matrices ")).intValue();
if (num_rreshtave > 0 && num_shtyllave > 0) {
	matrica = new double[num_rreshtave][num_shtyllave];
		}
		return matrica;
	}
	public static double[] mbusheVektorin() {
		for (int i = 0; i < vektori.length; i++)

		{
			vektori[i] = new Double(JOptionPane.showInputDialog("numrat"))
					.doubleValue();
		}

		return vektori;

	}

	public static double[][] mbusheMatricen() {
		for (int i = 0; i < matrica.length; i++) {
			for (int j = 0; j < matrica[0].length; j++) {
				matrica[i][j] = new Double(
						JOptionPane.showInputDialog("numrat")).doubleValue();
			}
		}

		return matrica;

	}



	
   
	public static double l2Norma(double[] v) {
		double c = 0;
		for (int i = 0; i < v.length; i++) {
			c += Math.pow(v[i], 2);
		}
		return Math.sqrt(c);

	}


	public static double infinitNorma(double[] v) {
		double max = Math.abs(v[0]);
		for (int i = 1; i < v.length; i++) {
			if (Math.abs(v[i]) > max) {
				max = v[i];
			}
		}
		return max;
	}


	public static double distancaEuklidiane(double[] x, double[] y) {
		double rez = 0;
		if (x.length == y.length) {
			for (int i = 0; i < x.length; i++) {
				rez += Math.pow(x[i] - y[i], 2);
			}
		}
		return Math.sqrt(rez);

	}

	public static double infinitDistanca(double[] x, double[] y) {
		double rez = 0;
		double max = 0;
		if (x.length == y.length) {
			for (int i = 0; i < x.length; i++) {
				rez = Math.abs(x[i] - y[i]);
				if (rez > max) {
					max = rez;
				}
			}

		}
		return max;

	}
	public static double InfinitMatric(double[][] A) {
		double s;
		double max = 0;
		for (int i = 0; i < A.length; i++) {
			s = 0;
			for (int j = 0; j < A[0].length; j++) {
				s += Math.abs(A[i][j]);
			}
			if (s > max) {
				max = s;
			}
		}
		return max;
	}

	public static double frobeniusNorma(double[][] matrica) {
		double rez = 0;
		for (int i = 0; i < matrica.length; i++) {
			for (int j = 0; j < matrica[0].length; j++) {
				rez = Math.pow(matrica[i][j], 2);
			}
		}
		return Math.sqrt(rez);

	}

	public static void main(String[] args) {
	  Norma n = new Norma();
		double[] v = definoVektorin();
		v = mbusheVektorin();
		double[] x = definoVektorin();
		x = mbusheVektorin();
		System.out.println(l2Norma(v));
		System.out.println(infinitNorma(v));
		System.out.println(n.distancaEuklidiane(x, v));
		double[][] A = definoMatricen();
		A = mbusheMatricen();

	}

}