import javax.swing.*;


  public class Det1 { 
   
   public static int[] k = new int[27]; 
   
 
   
   public static String ekriptimi(String s) {
   String c1 = "";
    k[0] = 89;
    for ( int i = 1;  i != k.length;  i = i+1 )
        { k[i] = 2*k[i-1]+49; }
        
    for ( int j = 0;  j != s.length();  j = j+1)
        { char c = s.charAt(j);
          if ( c == ' ' )
               { c1 = c1+" "+ k[0]; }
          else if ( c >= 'a'  &&  c <= 'z' )
               { int index = (c - 'a') + 1;
                 c1 = c1+" "+ k[index];
               }
        }
   return c1;
   }
   
    public static void main(String[] args) {
   
   System.out.println(ekriptimi("Analize"));
 
   }
}

