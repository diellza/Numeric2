import javax.swing.*;


public class PageRank {
	
   private static double[][] vektor ;
		

		public static double[][] matricaP( int N) {
		 	double[][] matrica = new double[N][N];
			for (int i = 0; i <= N - 1; i++) {
				int t = new Integer(JOptionPane.showInputDialog("  Me sa lidhet "
						+ (i + 1))).intValue();
				int count = t;
				while (count > 0) {
					int c = new Integer(JOptionPane.showInputDialog("Me ke lidhet "
							+ (i + 1))).intValue();
					matrica[i][c - 1] = 1.0 / t;
					count--;
				}

			}
			return matrica;
		}
		public static double [][] vekMat( double[][] v  ,  double[][]A)
		  { boolean proccessing = true; 
			Matrica c = new Matrica();  
		 
			double[][]rez = new double[v.length][1]; 
		 
		    double[][]Av= c.shumzoMatricat(A ,v);
		   
		   for(int i = 0; i < A.length; i++ )
		      {for (int j = 0; j < A[0].length; j++)
		      
		        while( proccessing )
		         {rez =c.shumzoMatricat(A ,Av); 
		         if(Av [i][j] == rez[i][j])
	         	  {proccessing = false;} 
		         else{ Av = rez;}
		         
		            
		          }
		      
		 }
		 return rez;  }
		
		public static double[][]definoVektorin(int N)
		{  vektor = new double[N][1];
		   for(int i = 0; i <vektor.length; i++ )
			   for(int j = 0; j <vektor[0].length; j++ )
		   		{{vektor[i][j] = 1.0/N;  }}
		return vektor;
			
		}
		public static void main(String[] args) {
			Matrica c = new Matrica();
			int  n = new Integer(JOptionPane.showInputDialog("Shkruj nr. e faqeve")).intValue();
			double [][]v =definoVektorin(n);
			double[][] m = c.transpono(matricaP(n));
			 m = vekMat(v , m );
			DecimalFormat f = new DecimalFormat("0.000");
			for (int i = 0; i <v.length; i++) {
				System.out.println(" ");
				for (int j = 0; j < v[0].length; j++) {
					System.out.print(f.format(m[i][j]) + " ");
				}
			}

		}
	}


